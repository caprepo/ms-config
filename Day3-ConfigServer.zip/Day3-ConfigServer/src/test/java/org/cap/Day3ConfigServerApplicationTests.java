package org.cap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day3ConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
